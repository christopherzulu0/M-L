"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow
} from "@/components/ui/table"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle
} from "@/components/ui/card"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger
} from "@/components/ui/dropdown-menu"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  Search,
  MoreHorizontal,
  Plus,
  Edit,
  Trash2,
  UserCog
} from "lucide-react"

// Define the User type based on the schema
interface User {
  id: number
  email: string
  firstName: string
  lastName: string
  role: string
  status: string
  profileImage?: string
  lastLogin?: Date
  createdAt: Date
}

export default function UsersPage() {
  const router = useRouter()
  const [users, setUsers] = useState<User[]>([])
  const [loading, setLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState("")

  useEffect(() => {
    // Fetch users data
    const fetchUsers = async () => {
      try {
        const response = await fetch("/api/users")
        if (response.ok) {
          const data = await response.json()
          setUsers(data)
        } else {
          console.error("Failed to fetch users")
        }
      } catch (error) {
        console.error("Error fetching users:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchUsers()
  }, [])

  // Filter users based on search query
  const filteredUsers = users.filter(user =>
    user.firstName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    user.lastName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    user.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
    user.role.toLowerCase().includes(searchQuery.toLowerCase())
  )

  // Get role badge color
  const getRoleBadgeColor = (role: string) => {
    switch (role.toLowerCase()) {
      case "admin":
        return "bg-red-500 hover:bg-red-600"
      case "agent":
        return "bg-blue-500 hover:bg-blue-600"
      case "user":
        return "bg-green-500 hover:bg-green-600"
      default:
        return "bg-gray-500 hover:bg-gray-600"
    }
  }

  // Get status badge color
  const getStatusBadgeColor = (status: string) => {
    switch (status.toLowerCase()) {
      case "active":
        return "bg-green-500 hover:bg-green-600"
      case "inactive":
        return "bg-gray-500 hover:bg-gray-600"
      case "suspended":
        return "bg-yellow-500 hover:bg-yellow-600"
      default:
        return "bg-gray-500 hover:bg-gray-600"
    }
  }

  return (
    <div className="container mx-auto py-6 px-4 md:px-6">
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between mb-6 gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">User Management</h1>
          <p className="text-muted-foreground">
            Manage users and their roles in the system
          </p>
        </div>
        <div className="flex items-center gap-2">
          <div className="relative">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search users..."
              className="pl-8 w-[200px] md:w-[300px]"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Users</CardTitle>
          <CardDescription>
            A list of all users in the system with their roles and status.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex justify-center items-center h-64">
              <p>Loading users...</p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>User</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>Role</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Last Login</TableHead>
                  <TableHead>Created</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredUsers.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center py-8">
                      No users found. {searchQuery && "Try a different search term."}
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredUsers.map((user) => (
                    <TableRow key={user.id}>
                      <TableCell>
                        <div className="flex items-center gap-3">
                          <Avatar>
                            <AvatarImage src={user.profileImage || ""} />
                            <AvatarFallback>
                              {user.firstName.charAt(0) + user.lastName.charAt(0)}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <p className="font-medium">{`${user.firstName} ${user.lastName}`}</p>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>{user.email}</TableCell>
                      <TableCell>
                        <Badge className={getRoleBadgeColor(user.role)}>
                          {user.role}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline" className={getStatusBadgeColor(user.status)}>
                          {user.status}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {user.lastLogin
                          ? new Date(user.lastLogin).toLocaleDateString()
                          : "Never"}
                      </TableCell>
                      <TableCell>
                        {new Date(user.createdAt).toLocaleDateString()}
                      </TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon">
                              <MoreHorizontal className="h-4 w-4" />
                              <span className="sr-only">Open menu</span>
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem
                              onClick={async () => {
                                // Implement inline edit functionality
                                const newFirstName = prompt("Enter new first name:", user.firstName);
                                const newLastName = prompt("Enter new last name:", user.lastName);

                                if (newFirstName && newLastName) {
                                  try {
                                    const response = await fetch(`/api/users/${user.id}`, {
                                      method: "PATCH",
                                      headers: {
                                        "Content-Type": "application/json",
                                      },
                                      body: JSON.stringify({
                                        firstName: newFirstName,
                                        lastName: newLastName,
                                      }),
                                    });

                                    if (response.ok) {
                                      // Refresh the user list
                                      const updatedUsers = users.map(u =>
                                        u.id === user.id
                                          ? { ...u, firstName: newFirstName, lastName: newLastName }
                                          : u
                                      );
                                      setUsers(updatedUsers);
                                      alert("User updated successfully");
                                    } else {
                                      alert("Failed to update user");
                                    }
                                  } catch (error) {
                                    console.error("Error updating user:", error);
                                    alert("An error occurred while updating the user");
                                  }
                                }
                              }}
                            >
                              <Edit className="mr-2 h-4 w-4" /> Edit
                            </DropdownMenuItem>
                            <DropdownMenuItem
                              onClick={async () => {
                                // Implement inline role management
                                const roles = ["user", "admin", "agent"];
                                const currentRoleIndex = roles.indexOf(user.role);
                                const newRole = prompt(
                                  "Enter new role (user, admin, agent):",
                                  user.role
                                );

                                if (newRole && roles.includes(newRole)) {
                                  try {
                                    const response = await fetch(`/api/users/${user.id}/role`, {
                                      method: "PATCH",
                                      headers: {
                                        "Content-Type": "application/json",
                                      },
                                      body: JSON.stringify({
                                        role: newRole,
                                      }),
                                    });

                                    if (response.ok) {
                                      // Refresh the user list
                                      const updatedUsers = users.map(u =>
                                        u.id === user.id
                                          ? { ...u, role: newRole }
                                          : u
                                      );
                                      setUsers(updatedUsers);
                                      alert("User role updated successfully");
                                    } else {
                                      alert("Failed to update user role");
                                    }
                                  } catch (error) {
                                    console.error("Error updating user role:", error);
                                    alert("An error occurred while updating the user role");
                                  }
                                } else if (newRole) {
                                  alert("Invalid role. Please enter 'user', 'admin', or 'agent'.");
                                }
                              }}
                            >
                              <UserCog className="mr-2 h-4 w-4" /> Manage Role
                            </DropdownMenuItem>
                            <DropdownMenuItem
                              className="text-red-600"
                              onClick={async () => {
                                if (confirm("Are you sure you want to delete this user?")) {
                                  try {
                                    const response = await fetch(`/api/users/${user.id}`, {
                                      method: "DELETE",
                                    });

                                    if (response.ok) {
                                      // Remove the user from the list
                                      setUsers(users.filter(u => u.id !== user.id));
                                      alert("User deleted successfully");
                                    } else {
                                      alert("Failed to delete user");
                                    }
                                  } catch (error) {
                                    console.error("Error deleting user:", error);
                                    alert("An error occurred while deleting the user");
                                  }
                                }
                              }}
                            >
                              <Trash2 className="mr-2 h-4 w-4" /> Delete
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
